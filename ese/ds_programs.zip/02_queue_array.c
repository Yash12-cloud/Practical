/* 02_queue_array.c */
int main(){return 0;}
