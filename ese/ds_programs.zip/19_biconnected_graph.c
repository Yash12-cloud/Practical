/* 19_biconnected_graph.c */
int main(){return 0;}
