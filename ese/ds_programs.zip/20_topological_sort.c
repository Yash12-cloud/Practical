/* 20_topological_sort.c */
int main(){return 0;}
