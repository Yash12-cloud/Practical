/* 06_decimal_to_binary.c */
int main(){return 0;}
