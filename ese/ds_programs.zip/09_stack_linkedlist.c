/* 09_stack_linkedlist.c */
int main(){return 0;}
