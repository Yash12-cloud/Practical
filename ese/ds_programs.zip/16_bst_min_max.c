/* 16_bst_min_max.c */
int main(){return 0;}
