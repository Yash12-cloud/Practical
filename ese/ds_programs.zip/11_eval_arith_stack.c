/* 11_eval_arith_stack.c */
int main(){return 0;}
