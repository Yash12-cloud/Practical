/* 08_infix_to_prefix.c */
int main(){return 0;}
