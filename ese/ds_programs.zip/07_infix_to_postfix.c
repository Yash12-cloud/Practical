/* 07_infix_to_postfix.c */
int main(){return 0;}
