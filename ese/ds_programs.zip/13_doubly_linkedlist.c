/* 13_doubly_linkedlist.c */
int main(){return 0;}
