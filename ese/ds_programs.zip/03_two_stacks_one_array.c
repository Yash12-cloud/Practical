/* 03_two_stacks_one_array.c */
int main(){return 0;}
