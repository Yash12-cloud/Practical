/* 18_trie_search.c */
int main(){return 0;}
