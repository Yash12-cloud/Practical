/* 12_linkedlist_full.c */
int main(){return 0;}
