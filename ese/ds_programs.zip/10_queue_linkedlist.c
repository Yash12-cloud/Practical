/* 10_queue_linkedlist.c */
int main(){return 0;}
