/* 01_stack_array.c */
int main(){return 0;}
