/* 04_two_queues_one_array.c */
int main(){return 0;}
